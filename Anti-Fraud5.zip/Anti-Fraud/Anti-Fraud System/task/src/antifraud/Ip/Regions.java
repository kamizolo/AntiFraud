package antifraud.Ip;

public enum Regions {
    EAP, ECA, HIC, LAC, MENA, SA
}

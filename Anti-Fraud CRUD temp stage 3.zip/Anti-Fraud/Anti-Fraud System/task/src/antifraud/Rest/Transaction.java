package antifraud.Rest;

import org.apache.tomcat.util.json.JSONParser;
import org.h2.util.json.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


import java.util.Objects;

@Controller
public class Transaction {
    String result = "";
    public String test(long amount) {
        if (amount <= 0) {
            return "BAD REQUEST";
        } else if (amount <= 200) {
            return "ALLOWED";
        } else if (amount <= 1500) {
            return "MANUAL_PROCESSING";
        } else {
            return "PROHIBITED";
        }
    }
    @PostMapping(value = "/api/antifraud/transaction", produces = MediaType.TEXT_HTML_VALUE)
    @ResponseBody
    //, @RequestParam String amount
    public ResponseEntity<String> result(@RequestBody String body) {
        //System.out.println("body: " + body + "|End");
        try {
            JSONParser parse = new JSONParser(body);
            String test = String.valueOf(parse.getToken(4));
            //System.out.println(test);

            //amount = body

            result = test(Long.parseLong(test));
            String json = "{\n" +
                    "   \"result\": \"" + result + "\"\n" +
                    "}";
            parse = new JSONParser(json);

            System.out.println(json);
            if (Objects.equals(result, "ALLOWED")) {
                return new ResponseEntity<String>(json, HttpStatus.OK);
            } else if (Objects.equals(result, "MANUAL_PROCESSING")) {
                return new ResponseEntity<>(json, HttpStatus.OK);
            } else if (Objects.equals(result, "PROHIBITED")) {
                return new ResponseEntity<>(json, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
        } catch (Exception ignore) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

}

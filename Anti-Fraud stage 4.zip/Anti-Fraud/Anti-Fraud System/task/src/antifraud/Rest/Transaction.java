package antifraud.Rest;

import antifraud.Card.CardRepository;
import antifraud.Card.StolenCard;
import antifraud.Ip.IpRepository;
import antifraud.Ip.SuspiciousIp;
import antifraud.User.User;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.tomcat.util.json.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;


import javax.transaction.Transactional;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Controller
public class Transaction {

    @Autowired
    IpRepository ipRepository;
    @Autowired
    CardRepository cardRepository;
    String result = "";
    public String test(long amount) {
        if (amount <= 0) {
            return "BAD REQUEST";
        } else if (amount <= 200) {
            return "ALLOWED";
        } else if (amount <= 1500) {
            return "MANUAL_PROCESSING";
        } else {
            return "PROHIBITED";
        }
    }
    @PostMapping(value = "/api/antifraud/transaction", produces = MediaType.TEXT_HTML_VALUE)
    public ResponseEntity<String> result(@RequestBody String body) {
        //System.out.println("body: " + body + "|End");
        try {
            JSONParser parse = new JSONParser(body);
            String test = String.valueOf(parse.getToken(4));
            //System.out.println(test);

            //amount = body

            result = test(Long.parseLong(test));
            String json = "{\n" +
                    "   \"result\": \"" + result + "\"\n" +
                    "}";
            parse = new JSONParser(json);

            System.out.println(json);
            if (Objects.equals(result, "ALLOWED")) {
                return new ResponseEntity<String>(json, HttpStatus.OK);
            } else if (Objects.equals(result, "MANUAL_PROCESSING")) {
                return new ResponseEntity<>(json, HttpStatus.OK);
            } else if (Objects.equals(result, "PROHIBITED")) {
                return new ResponseEntity<>(json, HttpStatus.OK);
            } else {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }
        } catch (Exception ignore) {
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping(path = "api/antifraud/stolencard")
    public ResponseEntity<String> getCards() throws JsonProcessingException {
        return new ResponseEntity<>(listOfObject(cardRepository.findAllByOrderByIdAsc()),HttpStatus.OK);
    }


    @PostMapping(path = "api/antifraud/stolencard")
    public ResponseEntity<String> insertCards(@RequestBody putCardRequest request){
        Optional<StolenCard> user = cardRepository.findCardByNumber(request.number);
        if (user.isPresent()) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        StolenCard card = new StolenCard();
        card.setNumber(request.number);
        cardRepository.save(card);
        return new ResponseEntity<>(HttpStatus.OK);}
    @Transactional
    @DeleteMapping(path = "api/antifraud/stolencard")
    public ResponseEntity<String> deleteCards(){return new ResponseEntity<>(HttpStatus.OK);}
    @GetMapping(path = "api/antifraud/suspicious-ip")
    public ResponseEntity<String> getIp() throws JsonProcessingException {
        return new ResponseEntity<>(listOfObject(ipRepository.findAllByOrderByIdAsc()),HttpStatus.OK);
    }
    @PostMapping(path = "api/antifraud/suspicious-ip")
    public ResponseEntity<String> insertIp(@RequestBody putIpRequest request){
        Optional<SuspiciousIp> user = ipRepository.findUserByIp(request.ip);
        if (user.isPresent()) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        SuspiciousIp ip = new SuspiciousIp();
        ip.setIp(request.ip());
        ipRepository.save(ip);
        return new ResponseEntity<>(HttpStatus.OK);}
    @Transactional
    @DeleteMapping(path = "api/antifraud/suspicious-ip")
    public ResponseEntity<String> deleteIp(){return new ResponseEntity<>(HttpStatus.OK);}

    public static String listOfObject (List<?> objects) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        StringBuilder output = new StringBuilder();
        output.append("[\n");
        for (Object c : objects) {
            output.append(objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(c)).append(",");
        }
        output.deleteCharAt(output.length() - 1);
        output.append("\n]");
        System.out.println(output.toString());
        return output.toString();
    }
    record putCardRequest(String number) {}
    record putIpRequest(String ip) {}
}
